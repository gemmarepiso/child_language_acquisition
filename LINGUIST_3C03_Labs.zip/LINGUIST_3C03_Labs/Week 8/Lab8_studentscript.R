#Child Language Acquisition
#mean_length_utterances

#Please copy your CORRECT input from the console and paste it under each corresponding question

#Question 1: Let's do a practice morpheme count with this utterance, "Mary eats an apple and Jack eats two bananas". How many morphemes are in the
# sentence? Hint, use a numeric value for the answer (i.e 1 not 'one')
# ANSWER HERE

#Question 2: Based off this table and our practice MLU_m value of 12, which stage of development is that?
# ANSWER HERE

#Question 3: Based off this table and our practice MLU_w value of 1.3, which stage of development is that?
# ANSWER HERE

#Question 4: How do we calculate the mean length utterance?
# ANSWER HERE

#Question 5: Using the get_speaker_statistics(), call information about Sarah from the Brown corpus. Save this under the variable name 
# 'Brown_Sarah'. Hint, since we only want utterances from the target_child, Sarah, specificy which role we want to pull from.  
# ANSWER HERE

#Question 6: 
# a) How many transcripts do we have for Sarah when she was 25 to 30 months old?
# ANSWER HERE

# b) Overall, which column seems to have a higher MLU value?
# ANSWER HERE

#Question 7: 
# a) Now let's compare this with a different age range. How many transcripts are available for Sarah from when she was 50-55 months old?
# ANSWER HERE

# b) Overall, which column seems to have a higher MLU value?
# ANSWER HERE

#Question 8: Based on the graph, what conclusions can we make?
# ANSWER HERE

