# Code placed in this file fill be executed every time the
      # lesson is started. Any variables created here will show up in
      # the user's working directory and thus be accessible to them
      # throughout the lesson.

library(childesr)

Stage <- c("1", "2", "3", "4", "5", "6")
MLU <- c("1.0-2.0", "2.0-2.5", "2.5-3.0", "3.0-3.75", "3.75-4.5", "4.5+")
Age <- c("12-26 months", "27-30 months", "31-34 months", "35-40 months", "41-46 months", "47+ months")
Characteristics <- c("Single-word/two-word utterances that express early semantic relationships, such as action-object and action-location",
                     "Emergence of grammatical inflections, such as -ing",
                     "Development of sentence types including declarative, interrogative, negative, imperatives",
                     "Emergence of sentence coordination using early conjunctions, such as 'and', 'because'",
                     "Continued development of complex sentences including coordination, complementation, and relativization",
                     "Continued refinement")
mlu_table <- tidyr::tibble(Stage, MLU, Age, Characteristics)

