#Child Language Acquisition_ANSWER SHEET
#Week 2: Introduction to RStudio and childesr

#Please copy your CORRECT input from the console and paste it under each corresponding question

#Question 1: The four panels visible on the screen are source, console, environment, files
# TRUE

#Question 2: If you wanted to ensure you have a sentence saved as a variable, which panel could easily show that?
# environment panel

#Question 3: Imagine you have never used the mean function before and want some clarification about what it does. How would you search for
# information about this function?
# ?mean

#Question 4: Imagine you want to use a sentence as a variable, but you do not want to have to type the sentence every single time you want
# to use it. Go ahead and save the sentence "the quick brown fox" as a character vector called x.
# x <- c('the', 'quick', 'brown', 'fox')

#Question 5: Now we also need another variable which has the length of x. Create a numeric vector which has the length of x, but save it 
# under the letter y. Hint, you can use length(x) to get the length of the sentence!
# y <- length(x)

#Question 6: Based off what you already know about the R-interface, where would you write commands? Please write your answer in lowercase.
# The format should be; in the (option 1) or (option 2)
# in the source or console

#Question 7: Try to install childesr using the install.packages function. We will be using childesr to be able to access the CHILDES
# database in R. 
# install.packages("childesr")

#Question 8: Load the package childesr using the library function
# library(childesr)

#Question 9: Do you have to install a package every single time you want to use it?
# No

#Question 10: Do you have to load a package every single time you want to use it?
# Yes

#Question 11: Why would we want to use childesr for corpus analysis?
# it is great for analyzing speech patterns in children

#SCRIPT RESPONSES HERE#
library(childesr)
x <- c(1, 2, 3, 4, 5)
y <- c("the quick brown fox jumped over the lazy dog")
mean_x <- mean(x)
nchar_y <- nchar(y)

