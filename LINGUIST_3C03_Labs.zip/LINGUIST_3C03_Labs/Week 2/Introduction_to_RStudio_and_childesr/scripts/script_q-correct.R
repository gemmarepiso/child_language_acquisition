
# Welcome to your script! A script is where we can write our code, save variables and save the code to run it later on. 

# This script is meant to get you used to using and seeing what different things do. 
# Anything written after a hashtag will be a comment. This means that it won't run if you were to write a function or command. 
# This is very useful to comment on pieces of code or to just write notes. 

# One thing to do when you open a script is to install and load all your necessary packages at the beginning, that way when you run the 
# script the packages will immediately load. 

#Lets load the childesr package we already installed; remember we use the library function to load packages! Type childesr in the brackets:

library(childesr)

# Scripts are also where we can save variables. Let's save a few variables just to practice.
#   a. save the numbers 1, 2, 3, 4, 5 into a variable called x
x <- c(1, 2, 3, 4, 5) 

#   b. save the sentence "the quick brown fox jumped over the lazy dog" into a variable called y 
y <- c("the quick brown fox jumped over the lazy dog")

# You're doing great! Lets now use these functions in some baseR functions. If you're ever curious what the function does, use the
# ? shortcut to get information about that function.

#   a. using the x variable, find the mean of x using mean(). Also call your new variable and write its output in your answer script!
mean_x <- mean(x)

#   b. using the y variable, find the number of characters using nchar(). Also call your new variable and write its output in your
#      answer script!
nchar_y <- nchar(y)

# Great job! To return to the lesson we need to save this script and then type submit() in the console. 
# Remember to save this script before submitting using any of these methods:
# - press the save button at the top
# - command S
# - file > save
