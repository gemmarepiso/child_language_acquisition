# Put custom tests in this file.
      
      # Uncommenting the following line of code will disable
      # auto-detection of new variables and thus prevent swirl from
      # executing every command twice, which can slow things down.
      
      # AUTO_DETECT_NEWVAR <- FALSE
      
      # However, this means that you should detect user-created
      # variables when appropriate. The answer test, creates_new_var()
      # can be used for for the purpose, but it also re-evaluates the
      # expression which the user entered, so care must be taken.

test_func <- function() {
    # Most of this test is wrapped within `try()` so that any error in the
    # student's implementation of `my_mean` doesn't interrupt swirl.
    try({
      func1 <- get('mean_x', globalenv())
      func2 <- get('nchar_y', globalenv())
      t1 <- identical(func1, mean(c(1:5)))
      t2 <- identical(func2, nchar("the quick brown fox jumped over the lazy dog"))
      ok <- all(t1, t2)
    }, silent = TRUE)
    # This value is returned at the result of the answer test.
    exists('ok') && isTRUE(ok)
}