#Let's give the function a try!

#Remember, these are the arguments for get_transcripts: 
get_transcripts(collection = NULL, corpus = NULL, target_child = NULL,connection = NULL,
                db_version = "current",db_args = NULL)
#Remember: not all arguments are mandatory


#REMEMBER how we used the get_participants function to retrieve participant data that involve children aged 2-3, who speak North American English and are males,
#NOW, let's use get_transcripts to retrieve the actual transcripts from the CHILDES database corresponding to the selected participants. 

#Click on the eng_data vatiable in your environment to view the tibble of the participants or run the following code:
view(participants)

#Now that you've had a look at the participants from the participants object, let's retrieve transcripts from a few of the participants
#Let's take a closer look at Charlie, Andrew, and John's transcripts 
#Use the get_transcripts function to retrieve the data

transcripts <- get_transcripts(collection = "Eng-NA", target_child = c("Charlie", "Andrew", "John")) #Fill in the arguments!
transcripts

#Nice! As you can see, the get_transcripts function allows us to retrieve the actual transcripts 
#from the CHILDES database corresponding to the selected participants. 
#In this case, we have retrieved the transcripts for children named Charlie, Andrew, and John, who are part of the Eng-NA collection.
#With get_transcripts, we have the ability to retrieve transcripts across multiple corpora simultaneously! This is both useful and convenient for researchers in their linguistic investigations.

#Be sure to save this script and type submit() in the console after you make your changes!

