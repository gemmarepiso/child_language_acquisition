#Let's give the function a try!

#Remember, these are the arguments for get_partcipants: 
get_participants(collection = NULL, corpus = NULL, target_child = NULL, role = NULL, 
                 role_exclude = NULL, age = NULL, sex = NULL, connection = NULL, db_version = "current", db_args = NULL)
#Hint: not all arguments are mandatory


#Use the get_participants function to retrieve participant data that involve children aged 2-3, who speak North American English and are males. 
#Hint: The age argument is in months!
#Hint: The language should be specified in the collection argument.
#Hint: Visit this link to find out what abbreviation is used for North American English: https://sla.talkbank.org/TBB/childes/Eng-NA 

participants <- get_participants(age = c(24, 36), sex = c("male"), collection = c("Eng-NA")) #Write your code here!
participants


#This scenario might be useful if you are conducting a research study and need to analyze participant data specifically 
#for children aged 2-3 who speak North American English and are males. By using the get_participants function with the provided arguments, 
#you can retrieve the relevant participant data from the transcripts. 
#This allows you to focus your analysis on the specific group of participants you are interested in. 

#Be sure to save this script and type submit() in the console after you make your changes!