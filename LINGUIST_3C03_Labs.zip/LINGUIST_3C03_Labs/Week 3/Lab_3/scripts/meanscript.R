#Let's say we have a vector of values representing the ages of a group of children: 
ages <- c(5, 4, 7, 4, 3)
#To find the average age, we can simply call the mean function on the ages vector, like this: 
mean(ages) 
#We can then save the output into a variable like this: 
average_age <- mean(ages)
average_age  

#The mean function can ALSO be used with a list of numbers as an argument, like this:
mean(1, 2, 3, 4, 6, 10, 11)

#Now, let's test it out! I want to calculate the mean number of syllables a child uses in their speech using the following vector called "syllables" 
#What would I need to type to calculate the mean of this vector? 
#Calculate the mean of this vector
syllables <- c(3, 4, 1, 2, 2, 1, 3)
avg_syllables <- #Write your code here!
avg_syllables

#Be sure to save this script and type submit() in the console after you make your changes!