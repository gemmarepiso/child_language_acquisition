# Put custom tests in this file.
      
      # Uncommenting the following line of code will disable
      # auto-detection of new variables and thus prevent swirl from
      # executing every command twice, which can slow things down.
      
      # AUTO_DETECT_NEWVAR <- FALSE
      
      # However, this means that you should detect user-created
      # variables when appropriate. The answer test, creates_new_var()
      # can be used for for the purpose, but it also re-evaluates the
      # expression which the user entered, so care must be taken.

test_func <- function() {
  # Most of this test is wrapped within `try()` so that any error in the
  # student's implementation of `my_mean` doesn't interrupt swirl.
  try({
    # The `get` function retrieves the student's definition of `my_mean` and
    # assigns it to the variable `func`.
    avg_syllables <- get('avg_syllables', globalenv())
    syllables <- c(3, 4, 1, 2, 2, 1, 3) 
    # The behavior of `func` is then tested by comparing it to the behavior of
    # `mean`.
    t1 <- identical(avg_syllables, mean(syllables))
    ok <- all(t1)
  }, silent = TRUE)
  
  # This value is returned at the result of the answer test.
  exists('ok') && isTRUE(ok)
}

test_func2 <- function() {
  # Most of this test is wrapped within `try()` so that any error in the
  # student's implementation of `my_mean` doesn't interrupt swirl.
  try({
    # The `get` function retrieves the student's definition of `my_mean` and
    # assigns it to the variable `func`.
    participants <- get('eng_data', globalenv())
    participants <- get_participants(age = c(24, 36), sex = c("male"), collection = c("Eng-NA"))
    # The behavior of `func` is then tested by comparing it to the behavior of
    # `mean`.
    t1 <- identical(participants, get_participants(age = c(24, 36), sex = c("male"), collection = c("Eng-NA")))
    ok <- all(t1)
  }, silent = TRUE)
  
  # This value is returned at the result of the answer test.
  exists('ok') && isTRUE(ok)
}

test_func3 <- function() {
  # Most of this test is wrapped within `try()` so that any error in the
  # student's implementation of `my_mean` doesn't interrupt swirl.
  try({
    # The `get` function retrieves the student's definition of `my_mean` and
    # assigns it to the variable `func`.
    transcripts <- get('transcripts', globalenv())
    transcripts <- get_transcripts(collection = "Eng-NA", target_child = c("Charlie", "Andrew", "John"))
    # The behavior of `func` is then tested by comparing it to the behavior of
    # `mean`.
    t1 <- identical(transcripts, get_transcripts(collection = "Eng-NA", target_child = c("Charlie", "Andrew", "John")))
    ok <- all(t1)
  }, silent = TRUE)
  
  # This value is returned at the result of the answer test.
  exists('ok') && isTRUE(ok)
}







