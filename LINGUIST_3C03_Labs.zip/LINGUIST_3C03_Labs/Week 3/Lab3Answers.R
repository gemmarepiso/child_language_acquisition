## LAB 3 ANSWERS ##

# In today's lesson, we explored the concept of functions and their significance in linguistic analysis, specifically corpus linguistics. 
# We covered the basics of functions, including their definition and structure. 
# We also learned about the childesr package, which provides functions for conducting corpus studies using the CHILDES database.
# We focused on two key functions from the childesr package, get_participants() and get_transcripts().
# In addition to subsetting, we utilized the nrow() function

# Copy and paste your answers into designated spaces below:

# Question 1: What are functions?
 

# Question 2: Calculate the mean of the syllables vector

# Question 3: The "age" argument in the "get_participants" function can accept a single age value or a range of ages.


# Question 4: The corpus argument in the get_participants function accepts a character vector of one or more names of corpora.


# Question 5: The target_child argument in the get_participants function accepts a numeric vector of age values.


# Question 6: Use the get_participants function to retrieve participant data that involve children aged 2-3, who speak North American English and are males.


#Question 9: How old was Doug when he was first recorded? 


# Question 10: What corpus is Doug's transcripts found in? 


# Question 11: At how many age levels were children studied?


# Question 12: The Bates corpus is a cross-sectional study.


# Question 13: The get_transcripts function retrieves transcripts based on criteria such as collection, corpus, participant ID, and transcription types.


# Question 14: The "corpus" argument in the "get_transcripts" function accepts only one corpus. 


# Question 15: What is the value returned by the get_transcripts function?


# Question 16: Use the get_transcripts function to retrieve Charlie, Andrew, and John's data


# Question 17: How many times was Charlie recorded? In other words, in how many files does Charlie appear?


# Question 18: Subset rows from the transcripts dataframe, where Charlie is present. Save the output to the variable "charlie_transcripts". 


# Question 19: Use nrow(), to count the number of rows where Charlie is present. Hint - the argument is what you just named the subset of rows where Charlie is found!


#GREAT WORK :)

