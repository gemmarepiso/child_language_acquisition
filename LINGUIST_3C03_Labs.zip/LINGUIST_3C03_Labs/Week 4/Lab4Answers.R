## LAB 4 ANSWERS ##

# In today's lesson, we focused the get_tokens() function from the childes package to explore various aspects of speech development in children 
# When focusing on Jane as our example, we observed how she demonstrated common patterns seen in early language development,
# including coda deletion, deletion of unstressed syllables, simplification of consonant clusters, 
# and delayed acquisition of certain sounds such as /l/. 

# Copy and paste your answers into designated spaces below:

# Question 1: What is the name of the collection this transcript is found in? Please write your answer EXACTLY how it is shown on the transcript


# Question 2: How old is the child in this transcript? The format on the transcript is year, month, days. 


# Question 3: Are the arguments for get_transcripts (collection, corpus and target_child) examples of character or numeric vectors?


# Question 4: Using the get_transcript function, call the transcript linked above and save it under Penney_Nar_D23 for now. 


# Question 5: Use the View() function to open the data we have saved under Penney_Nar_D23


# Question 6: Are there numeric arguments for get_tokens?


# Question 7: If I wanted to find tokens from female children who are under the age of 38 months and speak English,
# which arguments should I use?


# Question 8: In fact, lets try to do that! Use the get_tokens() function and get all instances of the token 'is' from our Penney corpus, 
# using D23s transcript.


# Question 9: How does participant D23 pronounce "is"? 


# Question 10: From the beginning to the end of this study, what was Jane's age? 


# Question 11: Use the get_tokens() function to retrieve all instances of the token 'book' spoken by Jane in the Cruttenden corpus. 
# Save your data to a variable called - books. 


# Question 12: Take a look at the first four rows of the data, specifically the actual_phonology column. 
# What do you notice about Jane's pronunciation of book? 


# Question 13: Use the get_tokens() function to retrieve all instances of the token 'mouth' spoken by Jane in the Cruttenden corpus. 
# Save your data to a variable called - mouth. 


# Question 14: Use the get_tokens() function to retrieve all instances of the tokens "paper", "biscuit", "birdie", and "pencil" spoken by Jane in the Cruttenden corpus. 
# Save your data to a variable called - more_words. 


# Question 15: What do you notice about Jane's pronunciation?


# Question 16: Use the get_tokens() function to retrieve all instances of the tokens "brush" and "plane" spoken by Jane in the Cruttenden corpus. 
# Save your data to a variable called - two_words 


# Question 17: Use the get_tokens() function to retrieve all instances of the tokens "ball" spoken by Jane in the Cruttenden corpus. 
# Save your data to a variable called - ball 

