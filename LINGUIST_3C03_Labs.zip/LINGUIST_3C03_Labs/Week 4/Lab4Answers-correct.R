## LAB 4 ANSWERS ##

# In today's lesson, we focused the get_tokens() function from the childes package to explore various aspects of speech development in children 
# When focusing on Jane as our example, we observed how she demonstrated common patterns seen in early language development,
# including coda deletion, deletion of unstressed syllables, simplification of consonant clusters, 
# and delayed acquisition of certain sounds such as /l/. 

# Copy and paste your answers into designated spaces below:

# Question 1: What is the name of the collection this transcript is found in? Please write your answer EXACTLY how it is shown on the transcript
Eng-NA

# Question 2: How old is the child in this transcript? The format on the transcript is year, month, days. 
5 years and 3 months

# Question 3: Are the arguments for get_transcripts (collection, corpus and target_child) examples of character or numeric vectors?
character

# Question 4: Using the get_transcript function, call the transcript linked above and save it under Penney_Nar_D23 for now. 
Penney_Nar_D23 <- get_transcripts(collection = "Eng-NA", corpus = "Penney", target_child = "D23")

# Question 5: Use the View() function to open the data we have saved under Penney_Nar_D23
View(Penney_Nar_D23)

# Question 6: Are there numeric arguments for get_tokens?
Yes

# Question 7: If I wanted to find tokens from female children who are under the age of 38 months and speak English,
# which arguments should I use?
sex, age, language

# Question 8: In fact, lets try to do that! Use the get_tokens() function and get all instances of the token 'is' from our Penney corpus, 
# using D23s transcript.
Penney_D23_tokens <- get_tokens(corpus = 'Penney', target_child = 'D23', token = "is")

# Question 9: How does participant D23 pronounce "is"? 
dəs

# Question 10: From the beginning to the end of this study, what was Jane's age? 
∼1 to ∼3 years old

# Question 11: Use the get_tokens() function to retrieve all instances of the token 'book' spoken by Jane in the Cruttenden corpus. 
# Save your data to a variable called - books. 
book <- get_tokens(corpus = 'Cruttenden', target_child = 'Jane', token = "book")

# Question 12: Take a look at the first four rows of the data, specifically the actual_phonology column. 
# What do you notice about Jane's pronunciation of book? 
the coda of book is missing 

# Question 13: Use the get_tokens() function to retrieve all instances of the token 'mouth' spoken by Jane in the Cruttenden corpus. 
# Save your data to a variable called - mouth. 
mouth <- get_tokens(corpus = 'Cruttenden', target_child = 'Jane', token = "mouth")

# Question 14: Use the get_tokens() function to retrieve all instances of the tokens "paper", "biscuit", "birdie", and "pencil" spoken by Jane in the Cruttenden corpus. 
# Save your data to a variable called - more_words. 
more_words <- get_tokens(corpus = 'Cruttenden', target_child = 'Jane', token = c("paper", "biscuit", "birdie","pencil"))

# Question 15: What do you notice about Jane's pronunciation?
Deletion of unstressed syllables

# Question 16: Use the get_tokens() function to retrieve all instances of the tokens "brush" and "plane" spoken by Jane in the Cruttenden corpus. Save your data to a variable called - two_words 
two_words <- get_tokens(corpus = 'Cruttenden', target_child = 'Jane', token = c("brush", "plane"))

# Question 17: Use the get_tokens() function to retrieve all instances of the tokens "ball" spoken by Jane in the Cruttenden corpus. Save your data to a variable called - ball 
ball <- get_tokens(corpus = 'Cruttenden', target_child = 'Jane', token = "ball")
