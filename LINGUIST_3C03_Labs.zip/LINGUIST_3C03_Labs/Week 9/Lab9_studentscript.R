##Child Language Acquisition
## LAB 9 ANSWERS ##


#In today's lesson, we examined the different parts of speech, explored the concept of morphological tier, and further investigated the order of acquisition.  
#We also explored question formation in children's speech, through filtering columns. 

#Please copy your answers from the console and paste them on this document

#Question 1: Open the variable named 'eve_morph' with the View() function
# ANSWER HERE

#Question 2 : Let's find all instances of pronoun subjects for the target child Eve from the Brown corpus when she was 24 months old.
# Save this under the variable name eve_subject
# ANSWER HERE

#Question 3: Now we can use the nrow() function to count how many times Eve has uttered a pronoun subject
# ANSWER HERE

#Question 4: How many pronoun subjects are reported?
# ANSWER HERE

#Question 5: Let's find all instances of object pronouns for the target child Eve from the Brown corpus when she was 24 months old.
# Save this under the variable name eve_object
# ANSWER HERE

#Question 6: Now we can use the nrow() function to count how many times Eve has uttered an object pronoun
# ANSWER HERE

#Question 7: How many object pronouns are reported?
# ANSWER HERE

#Question 8: Make a barplot of the object and subject pronouns by following this format - barplot(c(subject = nrow(eve_subject), object = nrow(eve_object)))
# ANSWER HERE

#Question 9: Which category has the most amount of utterances?
# ANSWER HERE

#Question 10: Which category has the least amount of utterances?
# ANSWER HERE

#Question 11: Use the get_utterances() function to retrieve utterances from Lucy in the Cruttenden corpus. Save your data to a variable called - Lucy. 
# ANSWER HERE

#Question 12: In which age range, throughout the files, does Lucy ask questions?
# ANSWER HERE

#Question 13: How does Lucy ask "where" questions?
# ANSWER HERE

#Question 14: What grammatical mistake is being made in the given sentences?
# ANSWER HERE
