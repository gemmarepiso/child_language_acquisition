##Child Language Acquisition
## LAB 9 ANSWERS ##


#In today's lesson, we examined the different parts of speech, explored the concept of morphological tier, and further investigated the order of acquisition.  
#We also explored question formation in children's speech, through filtering columns. 


#Please copy your answers from the console and paste them on this document

#Question 1: Open the variable named 'eve_morph' with the View() function
# View(eve_morph)

#Question 2 : Let's find all instances of pronoun subjects for the target child Eve from the Brown corpus when she was 24 months old.
# Save this under the variable name eve_subject
# eve_subject <- get_tokens(corpus = "Brown", target_child = "Eve", role = "target_child", age = 24, token = "*", part_of_speech = "pro:sub")

#Question 3: Now we can use the nrow() function to count how many times Eve has uttered a pronoun subject
# nrow(eve_subject)

#Question 4: How many pronoun subjects are reported?
# 190

#Question 5: Let's find all instances of object pronouns for the target child Eve from the Brown corpus when she was 24 months old.
# Save this under the variable name eve_object
# eve_object <- get_tokens(corpus = "Brown", target_child = "Eve", role = "target_child", age = 24, token = "*", part_of_speech = "pro:obj")

#Question 6: Now we can use the nrow() function to count how many times Eve has uttered an object pronoun
# nrow(eve_object)

#Question 7:How many object pronouns are reported?
# 48

# Question 8: Make a barplot of the object and subject pronouns by following this format - barplot(c(subject = nrow(eve_subject), object = nrow(eve_object)))
# barplot(c(subject = nrow(eve_subject), object = nrow(eve_object)))

#Question 9: Which category has the most amount of utterances?
# Nouns

#Question 10: Which category has the least amount of utterances?
# Object Pronouns

#Question 11: Use the get_utterances() function to retrieve utterances from Lucy in the Cruttenden corpus. Save your data to a variable called - Lucy. 
#Lucy <- get_utterances(corpus = 'Cruttenden', target_child = 'Lucy')

#Question 12: In which age range, throughout the files, does Lucy ask questions?
#~ 24 to ~ 42 months

#Question 13: How does Lucy ask "where" questions?
#where we go AND where we are

#Question 14: What grammatical mistake is being made in the given sentences?
#Subject-verb inversion

