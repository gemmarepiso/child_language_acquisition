# Code placed in this file fill be executed every time the
      # lesson is started. Any variables created here will show up in
      # the user's working directory and thus be accessible to them
      # throughout the lesson.

Eve <- get_utterances(corpus = "Brown", target_child = "Eve", role = "target_child", age = 24)
eve_morph<- tidyr::tibble(gloss = Eve$gloss, stem = Eve$stem, type = Eve$type, part_of_speech = Eve$part_of_speech)
