
eve_morph_table <- tibble::tibble(Noun = nrow(get_tokens(corpus = "Brown", target_child = "Eve", role = "target_child", age = 24, token = "*", part_of_speech = "n")), 
                                  Verb = nrow(get_tokens(corpus = "Brown", target_child = "Eve", role = "target_child", age = 24, token = "*", part_of_speech = "v")),
                                  Subject_Pronoun = nrow(get_tokens(corpus = "Brown", target_child = "Eve", role = "target_child", age = 24, token = "*", part_of_speech = "pro:sub")), 
                                  Object_Pronoun = nrow(get_tokens(corpus = "Brown", target_child = "Eve", role = "target_child", age = 24, token = "*", part_of_speech = "pro:obj")))

barplot(as.matrix(eve_morph_table))
