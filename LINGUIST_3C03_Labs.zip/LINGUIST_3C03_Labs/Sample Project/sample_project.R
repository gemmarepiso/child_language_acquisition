#LINGUIST 3C03 - Sample Project

#This is the sample project of what is expected for your final project using childesr. 

#This is the R script portion of the final project, where you would 'show your work' (i.e running codes, saving variables, plotting graphs) 

#For this sample project, we are focusing on the study linked in the corresponding word document. This study uses the FerFuLice corpus from
#childes talkbank.

library(childesr)

#Try and use functions discussed in the labs/modules such as:
get_transcripts()
get_utterances()
get_tokens()
get_speaker_statistics()
get_types()
plot()
barplot()

#####Section One - Background and Research Questions #####
#In this section provide a brief background on the corpus or corpora used. 
#Since the FerFuLice corpus looks at 3 different conditions, Spanish, English and Bilingual for two participants, save them all under a
#corresponding variable:


#####Section Two - Participant Description #####
#In this section provide a brief description of the participants. This includes the age/age range, their MLU and their type token ratio.

participant1 <- get_speaker_statistics(corpus = " ", target_child = " ")
participant2 <- get_speaker_statistics(corpus = " ", target_child = " ")

participant1_type_tokens <- participant1[, c('target_child_age','mlu_m','mlu_w','num_types', 'num_tokens')]
participant2_type_tokens <- participant2[, c('target_child_age','mlu_m','mlu_w','num_types', 'num_tokens')]


#####Section Three - Corpus Analysis #####
#In this section, you will be detailing the ‘methodology’ of your project. What functions have you used and why were they used? What values
#were calculated based on these functions? How did you choose to plot your results? 
  
participant1_type_tokens$ttr <- (participant1_type_tokens$num_types / particpant1_type_tokens$num_tokens) * 100
participant2_type_tokens$ttr <- (participant2_type_tokens$num_types / particpant2_type_tokens$num_tokens) * 100

#Let's begin gathering day by retrieving all utterances from the FerFuLice corpus.

#Use the 'get_utterances' function to retrieve all utterances from the FerFuLice corpus.
#Specify the 'role' argument as 'target_child'.
#Assign the result to a variable named 'FerFuLice_utts'.
FerFuLice_utts <- get_utterances(corpus = '', role = '')
View(FerFuLice_utts)

#In this corpus, Leo (CHI) primarily speaks in Spanish and Simon (CHI2) primarily speaks in English, but both grew up in a bilingual environment
#Keep this in mind when you begin analyzing the utterances!

#In R, the grepl function is used for pattern matching.
#Using !grepl allows you to perform negative pattern matching. It enables you to filter out rows or elements that do not match a specific pattern or condition.

#For this project, we will be focussing on the verb,'am', in English and in Spanish.

#First, subset 'declarative' sentences from the column 'type'.
FerFuLice_utts <- FerFuLice_utts[grepl(" ", FerFuLice_utts$column_name_here), ]

#Now, create a subset of the FerFuLice_utts dataset where the infinitive verbs ('v inf') are excluded from the 'part_of_speech' column. 
#This subset will only contain entries that do not have infinitive verbs.
#This is done to isolate and focus specifically on inflected and non-inflected verbal forms
#Infinitive verbs, by definition, are non-inflected forms of verbs that do not show agreement with the subject or tense. 

FerFuLice_utts <- FerFuLice_utts[!grepl(" ", FerFuLice_utts$column_name_here), ]

## ENGLISH ##

#Use subsetting to retrieve all instances of the English word, 'am' from the 'FerFuLice_utts' dataset
#Save your data to a variable named "eng_utts"
#When retrieving each word, make sure to surround the word with \\b to isolate it and ensure that it matches the word boundaries
#This ensures that the search won't pick up partial matches or variations of the word. 
#This is important for accurate and specific retrieval of the desired word instances. 
#For example, to retrieve the word "dog", you would use "\\bdog\\b" 

#Create a subset of the 'FerFuLice_utts' dataset to extract all occurrences of the English word 'am' from the 'gloss' column.
eng_utts <- FerFuLice_utts[grepl(" ", FerFuLice_utts$column_name_here), ]
View(eng_utts)

## SPANISH ##

#Use subsetting to retrieve instances of the Spanish word, 'soy' ('am') from the 'gloss' column from the 'FerFuLice_utts' dataset

#First, create a subset of Spanish utterances including overt subject pronouns. 
#In this case, include 'yo' ('I') in front of 'soy'. 
spa_utts_overt_pronoun <- FerFuLice_utts[grepl("\\b   \\b", FerFuLice_utts$column_name_here), ]

#Now, create a subset of Spanish utterances with null subject pronouns. 
#Save your data to a variable named "spa_utts"
#When retrieving each word, make sure to surround the word with \\b to isolate it and ensure that it matches the word boundaries

#To view all the words at once, create a subset of the 'FerFuLice_utts' dataset to extract all occurrences of the Spanish word 'soy' from the 'gloss' column.
spa_utts <- FerFuLice_utts[grepl("\\b    \\b", FerFuLice_utts$column_name_here), ]
View(spa_utts)

## NULL vs. OVERT subject pronouns ##

#Now, compare the frequency of overt subject pronouns and null subject pronouns
#Calculate the frequency of spa_utts_overt_pronoun for the total spa_utts 
#Remember, we created these 2 subsets
View(spa_utts_overt_pronoun) #'spa_utts_overt_pronoun' is a subset of overt pronouns in Spanish 
View(spa_utts) #'spa_utts' is a subset of null AND overt pronouns in Spanish. 

#Calculate the frequencies of null pronouns and overt pronouns for Spanish utterances:
#a. Calculate the number of utterances with null pronouns. Subtract 'spa_utts_overt_pronoun' from 'spa_utts'
#Use the nrow() function to calculate the number of rows for each dataset.
spa_total_null <- function_name(spa_utts) - function_name(spa_utts_overt_pronoun)

#b. Calculate the frequency of Null pronouns 
#Hint: number of utterances with null pronouns / total number of utterances 
spa_freq_null <- spa_total_null / function_name(spa_utts)

#c. Calculate the frequency of Overt pronouns 
#Hint: number of utterances with overt pronouns / total number of utterances 
spa_freq_overt <- function_name(spa_utts_overt_pronoun) / function_name(spa_utts)

#Let's view this trend. Plot a bar graph to show the frequency of overt and null pronouns
spa_plot <- barplot(c(spa_freq_overt, spa_freq_null), names.arg = c("Overt Pronoun", "Null Pronoun"), 
                    ylab = "Frequency", main = "Frequency of Overt and Null Pronouns in Spanish")

#Calculate the frequencies of null pronouns and overt pronouns for English utterances:
#Run this:
eng_utts_overt_pronoun <- eng_utts[grepl("\\bI am\\b", eng_utts$gloss), ]

#a. Calculate the number of utterances with null pronouns. Subtract 'eng_utts_overt_pronoun' from 'eng_utts'
#Use the nrow() function to calculate the number of rows for each dataset.
eng_total_null <- function_name(eng_utts) - function_name(eng_utts_overt_pronoun)

#b. Calculate the frequency of Null pronouns 
#Hint: number of utterances with null pronouns / total number of utterances 
eng_freq_null <- eng_total_null / function_name(eng_utts)

#c. Calculate the frequency of Overt pronouns 
#Hint: number of utterances with overt pronouns / total number of utterances 
eng_freq_overt <- function_name(eng_utts_overt_pronoun) / function_name(eng_utts)

#Let's view this trend. Plot a bar graph to show the frequency of overt and null pronouns
eng_plot <- barplot(c(eng_freq_overt, eng_freq_null), names.arg = c("Overt Pronoun", "Null Pronoun"), 
                    ylab = "Frequency", main = "Frequency of Overt and Null Pronouns in English")

#Compare 'spa_plot' to 'eng_plot'. 
#What do you notice about the sizes of the Overt Pronoun and Null Pronoun bar sizes?
#What could this mean? 

#As you can see in Spanish, there are some instances where 'soy' is said with an overt pronoun, like in the sentences, "yo soy bueno"(I am good) and "yo soy segundo" (I am second).
#In Spanish, it is common to omit the subject pronoun when using the verb "ser" (to be) with the first-person singular form "soy" (I am)
#Do you think the use of overt pronouns in Spanish in this dataset is because the children are being influenced by the English language?
#Remember, in the original study, the twins grew up in a bilingual environment, where they were exposed to both English and Spanish
#For a future study, what is a baseline we can compare the twins' language to? 

#####Section Four - Results #####
#Here you will be detailing your results. What did you find? What graphs did you create? What conclusions can you make based on the information you
#found?

#Show a plot of the number of null and overt pronouns used in both Spanish and English

#Show a barplot of the number of null and over for BOTH languages (2 plots, one for English and one for Spanish)


