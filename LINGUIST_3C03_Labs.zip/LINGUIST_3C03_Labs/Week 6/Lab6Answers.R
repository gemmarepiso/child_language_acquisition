## LAB 6 ANSWERS ##

# In today's lesson, using the function 'get_speaker_statistics', we explored an important aspect of children's language development: vocabulary size. 
# We learned about tokens and types, which are valuable indicators of a child's speech development. 
# We also discussed the type-token ratio (TTR), a significant metric that measures lexical diversity. 
# Using the get_speaker_statistics() function and the num_types and num_tokens columns from the ComptonPater corpus, 
# we calculated Julia's TTR for each transcript, providing insights into the diversity and richness of her vocabulary. 
# We also practiced filtering the data set to focus only on the necessary columns and even a new column for our analysis. 

# Copy and paste your answers into designated spaces below:

# Question 1: How would you define tokens in the context of child language development?


# Question 2: How would you define types in the context of child language development?


# Question 3: Use the get_speaker_statistics() function to retrieve data from Julia in the ComptonPater corpus. 
# Save your data to a variable called - julia_stats. 


# Question 3: Use indexing to filter the `julia_stats` data frame to only include the `target_child_age`, `num_types` and `num_tokens` columns. 
# Save the filtered data frame to a new variable called `julia_types_tokens`.


# Question 4: Based on the filtered dataset and Julia's use of types and tokens over time, what general trend do you observe?



# Question 5: Use the `barplot()` function to create a bar graph showing the number of types for each transcript in `julia_types_tokens` dataset. 
# Pass the column of interest, num_types, from the julia_types_tokens dataset as the data for the bars (Hint - dataset$column_name). 
# Customize the plot by setting the the xlab argument to "Transcript" and the ylab argument to "Number of Types".


# Question 6: Create another bar graph to visualize the number of tokens for each transcript in `julia_types_tokens`. 
# Pass the column of interest, num_tokens, from the julia_types_tokens dataset as the data for the bars (Hint - dataset$column_name). 
# Customize the plot by setting the the xlab argument to "Transcript" and the ylab argument to "Number of Tokens".


# Question 7: Calculate the mean of the "num_types" column of the "julia_types_tokens" dataset using the mean() function. 


# Question 8: Calculate the mean of the "num_tokens" column of the "julia_types_tokens" dataset using the mean() function. 


# Question 9: Create a new column in the `julia_types_tokens` data frame called `ttr` that calculates the type-token ratio using the formula: TTR = (Number of Types / Number of Tokens) * 100.


# Question 10: Use the `plot()` function to create a plot to visualize how Julia's type-token ratio (TTR) changes over time. 
# Pass the `target_child_age` column as the x-axis values and the `ttr` column as the y-axis values. 
# Customize the plot by setting the xlab argument to "Age (Months)" and the ylab argument to "Type-Token Ratio".


