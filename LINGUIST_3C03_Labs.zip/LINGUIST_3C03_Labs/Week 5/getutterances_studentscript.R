##Child Language Acquisition
#Using get_utterances and Learning Words

#Please copy your answers from the console and paste them on this document

#Question 1: If you wanted to get the utterances for Julia from the ComptonPater corpus, which arguments should you use?
# ANSWER HERE

#Question 2 : What type of sounds are most likely to be produced in the babbling stage
# ANSWER HERE

#Question 3: If an infant is saying 'dada' and 'wawa', what kind of babbling would this utterance be?
# ANSWER HERE

#Question 4: Which stage is most likely occurring for a 22 month old child
# ANSWER HERE

#Question 5: Jack is visiting a farm and everytime he sees a four-legged animal, he calls it a sheep. Jack is 24 months old and is nearing the end of
# the two-wordstage. What is this instance an example of?
# ANSWER HERE

#Question 6:  We want to use the childesr function to pull information from a transcript found in the ComptonPater corpus for Trevor from when he was
# 11 months old. Using the get_utterances function, call this specific transcript and save it under the name trevor_utterances.
# ANSWER HERE

#Question 7: Based on the utterances, what stage of development is Trevor showcasing at 11 months old?
# ANSWER HERE

#Question 8: Let's call all of Julia's transcripts using the get_utterances function and save this under the name utterances.
# ANSWER HERE

#Question 9: Use the function nrow() and put the variable utterances within the brackets. How many utterances has Julia made?
# ANSWER HERE

#Question 10:
#   a) What stage of development is Julia at when she was 16 months to 18 months old?
#      ANSWER HERE

#   b) What stage of development is Julia at when she was 20 months to 24 months old?
#     ANSWER HERE

#   c) What stage of development is Julia at when she was 26 months to 30 months old?
#     ANSWER HERE

#   d) What stage of development is Julia at when she was 36 months to 38 months old?
#     ANSWER HERE



